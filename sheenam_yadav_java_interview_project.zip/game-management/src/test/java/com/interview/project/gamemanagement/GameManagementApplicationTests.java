package com.interview.project.gamemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
