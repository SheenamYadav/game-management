package com.interview.project.gamemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameManagementApplication.class, args);
	}

}
